import Container from "../../Layout/Container/Container"

const Home = () => {
  return (
    <div>
          <Container>
          <h2 className="text-3xl font-bold">landing page contain goes here</h2>
      </Container>
    </div>
  )
}

export default Home
