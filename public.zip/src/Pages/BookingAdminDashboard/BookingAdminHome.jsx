
const BookingAdminHome = () => {
  return (
    <div>
      <h1>Booking admin dashboard home</h1>
    </div>
  )
}

export default BookingAdminHome
